package com.example.plantscape;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity4 extends AppCompatActivity {

    private TextView textViewWelcome;
    private ImageButton iconProfile;
    private EditText editTextFullName;
    private EditText editTextEmail;
    private Button buttonLogin;
    private ImageButton buttonFacebook;
    private ImageButton buttonGoogle;
    private ImageButton buttonApple;
    private ImageView backIcon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        // Initialize views
        textViewWelcome = findViewById(R.id.textViewWelcome);
        editTextFullName = findViewById(R.id.editTextFullName);
        editTextEmail = findViewById(R.id.editTextEmail);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonFacebook = findViewById(R.id.buttonFacebook);
        buttonGoogle = findViewById(R.id.buttonGoogle);
        buttonApple = findViewById(R.id.buttonApple);

        // Set onClickListener for login button
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fullName = editTextFullName.getText().toString().trim();
                String email = editTextEmail.getText().toString().trim();

                if (fullName.isEmpty() || email.isEmpty()) {
                    Toast.makeText(MainActivity4.this, "Please enter your full name and email", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity4.this, "Login successful!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        backIcon = findViewById(R.id.backIcon);
        backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Go back to the previous activity
            }
        });

        // Set onClickListeners for social buttons (Add your own logic here)
        buttonFacebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Facebook login
            }
        });

        buttonGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Google login
            }
        });

        buttonApple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Apple login
            }
        });
    }
}
