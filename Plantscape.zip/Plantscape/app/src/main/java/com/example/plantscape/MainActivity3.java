package com.example.plantscape;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {

    private ImageView backIcon, searchIcon, favoriteIcon, shareIcon;
    private boolean isFavorite = false; // To track favorite status

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        // Initialize Views
        backIcon = findViewById(R.id.backIcon);
        favoriteIcon = findViewById(R.id.favoriteIcon);
        shareIcon = findViewById(R.id.shareIcon);

        // Back Icon Click
        backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Go back to the previous activity
            }
        });


        // Favorite Icon Toggle
        favoriteIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isFavorite = !isFavorite; // Toggle the favorite status
                if (isFavorite) {
                    favoriteIcon.setImageResource(R.drawable.ic_red_heart); // Change to filled heart icon
                    Toast.makeText(MainActivity3.this, "Added to Favorites", Toast.LENGTH_SHORT).show();
                } else {
                    favoriteIcon.setImageResource(R.drawable.ic_heart); // Change back to empty heart icon
                    Toast.makeText(MainActivity3.this, "Removed from Favorites", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Share Icon Click
        shareIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Monstera Adansonii");
                shareIntent.putExtra(Intent.EXTRA_TEXT, "Check out this amazing plant: Monstera Adansonii! Perfect for indoor environments.");

                startActivity(Intent.createChooser(shareIntent, "Share via"));
            }
        });
    }
}
